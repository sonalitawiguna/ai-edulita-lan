import { IndustryDashboard } from "@/components/dashboards/industry-dashboard"

export default function IndustryDashboardPage() {
  return <IndustryDashboard />
}
