import { PrincipalDashboard } from "@/components/dashboards/principal-dashboard"

export default function PrincipalDashboardPage() {
  return <PrincipalDashboard />
}
